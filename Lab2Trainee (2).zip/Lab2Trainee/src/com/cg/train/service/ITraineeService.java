package com.cg.train.service;

import java.util.List;

import com.cg.train.beans.TraineeBean;
import com.cg.train.exception.TraineeException;



public interface ITraineeService {

	/****************************************
	 * For Adding trainee
	 * ***************************************/
	public TraineeBean addTrainee(TraineeBean traineeBean) throws TraineeException;
	
	/********************************
	 * For deleting trainee by id
	 * *****************************/
	public TraineeBean getTraineeById(int traineeId) throws TraineeException;
	
	public TraineeBean removeTraineeById(int traineeId) throws TraineeException;
	
	/********************************
	 * To retrieve all trainee details
	 * *************************************/
	
	public List<TraineeBean> getallDetail() throws TraineeException;

	/**************************
	 * To retrieve by id
	 * ******************************/
	public TraineeBean retrieveByID(int traineeId) throws TraineeException;
	
	
/******************************************
 * To modify details
 * *************************************/
	
	public TraineeBean modifyTrainee(TraineeBean traineeBean) throws TraineeException;
}
