package com.cg.train.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.train.beans.TraineeBean;
import com.cg.train.dao.ITraineeDao;
import com.cg.train.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao;

	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public TraineeBean addTrainee(TraineeBean traineeBean)
			throws TraineeException {
		return traineeDao.addTrainee(traineeBean);
	}

	@Override
	public TraineeBean getTraineeById(int traineeId) throws TraineeException {
		return traineeDao.getTraineeById(traineeId);
	}

	@Override
	public List<TraineeBean> getallDetail() throws TraineeException {
		return traineeDao.getallDetail();
	}

	@Override
	public TraineeBean removeTraineeById(int traineeId) throws TraineeException {
		return traineeDao.removeTraineeById(traineeId);
	}

	@Override
	public TraineeBean retrieveByID(int traineeId) throws TraineeException {
		return traineeDao.retrieveByID(traineeId);
	}

	@Override
	public TraineeBean modifyTrainee(TraineeBean traineeBean)
			throws TraineeException {
		return traineeDao.modifyTrainee(traineeBean);
	}

}
