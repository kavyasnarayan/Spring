package com.cg.train.beans;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


public class UserBean {

	
	@Override
	public String toString() {
		return "UserBean [userName=" + userName + ", password=" + password
				+ "]";
	}
	@NotEmpty(message="Please Enter User Name")
	@Pattern(regexp="^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String userName;
	
	@NotEmpty(message="Please enter password")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Username must contain only alphabets")
	private String password;
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
