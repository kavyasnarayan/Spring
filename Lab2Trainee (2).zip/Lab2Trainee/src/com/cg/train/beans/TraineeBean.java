package com.cg.train.beans;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee_master")
public class TraineeBean implements Serializable {


	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "TraineeBean [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
//	@Size(min=1,max=3,message="ID should contain only digits")
//	@Pattern(regexp="^[0-9]+$", message="Username must contain only numbers()")
	@Column(name="trainee_id")
	private int traineeId;
	
	@NotEmpty(message="Please Enter Trainee Name")
	@Pattern(regexp="^[a-zA-Z]+$", message="Username must contain only alphabets")
	@Column(name="trainee_name")
	private String traineeName;
	
	@Column(name="trainee_domain")
	@NotEmpty(message="Please Choose trainee domain")
	private String traineeDomain;
	
	
	@Column(name="trainee_location")
	@NotEmpty(message="Please Choose trainee location")
	private String traineeLocation;
	
//	public TraineeBean(int traineeId, String traineeName, String traineeDomain,
//			String traineeLocation) {
//		super();
//		this.traineeId = traineeId;
//		this.traineeName = traineeName;
//		this.traineeDomain = traineeDomain;
//		this.traineeLocation = traineeLocation;
//	}
//	
	
	
	public TraineeBean() {
		super();
	}



	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
}
