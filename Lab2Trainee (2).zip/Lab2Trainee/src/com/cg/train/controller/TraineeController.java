package com.cg.train.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.train.beans.TraineeBean;
import com.cg.train.beans.UserBean;
import com.cg.train.exception.TraineeException;
import com.cg.train.service.ITraineeService;

@Controller
public class TraineeController {

	public static final Logger LOGGER=Logger.getLogger(TraineeController.class);
	@Autowired
	ITraineeService traineeService;

	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	/************************************
	 * Login page
	 * **********************************/
	@RequestMapping(value = "/showHomePage", method = RequestMethod.GET)
	public String showLoginPage(Model model) throws Exception {
		UserBean bean = new UserBean();
		model.addAttribute("bean", bean);
		return "login";
	}

	@RequestMapping("/checkLogin")
	public String authenticateUser(
			@ModelAttribute(value = "bean") @Valid UserBean bean,
			BindingResult result, Model model) {
		if (result.hasErrors()) {
			System.out.println("any error");
			return "login";
		}
		if (bean.getUserName().equals("admin")
				&& bean.getPassword().equals("admin")) {
			model.addAttribute("bean", bean);
			model.addAttribute("msg", "Successfully Login");
			return "operationPage";
		} else {
			model.addAttribute("msg", "Wrong Credentials");
			return "login";
		}
	}

	/**********************************************
	 * Operation page
	 * ******************************************/

	@RequestMapping("/operationPage")
	public String getPage() {
		return "operationPage";
	}

	/************************************************
	 * Add Trainee to database
	 * **********************************************/

	@RequestMapping("/showAddTraineeForm")
	public ModelAndView showAddTrainee() {
		TraineeBean traineeBean = new TraineeBean();
		return new ModelAndView("addTrainee", "traineeBean", traineeBean);

	}

	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("traineeBean") @Valid TraineeBean traineeBean,
			BindingResult result) throws TraineeException {

		ModelAndView view = null;
		if (!result.hasErrors()) {
			try {
				traineeBean = traineeService.addTrainee(traineeBean);
				view = new ModelAndView("addSuccess");
				view.addObject("traineeId", traineeBean.getTraineeId());
				view.addObject("traineeName", traineeBean.getTraineeName());
			} catch (TraineeException e) {
				throw new TraineeException(e.getMessage());
			}

		} else {
			view = new ModelAndView("addTrainee", "traineeBean", traineeBean);
		}

		return view;

	}

	/**************************************************
	 * Delete trainee from database
	 *****************************************************/
	@RequestMapping("/ShowDeleteTraineeForm")
	public String showdeleteTrainee(Model model) {
		model.addAttribute("traineeBean", new TraineeBean());
		return "deleteTrainee";
	}

	@RequestMapping(value = "/deleteTrainee", method = RequestMethod.POST)
	public String deleteTraineeById(
			@ModelAttribute("traineeBean") TraineeBean traineeBean, Model model,BindingResult result) {
		try {
			traineeBean = traineeService.getTraineeById(traineeBean
					.getTraineeId());
			if (traineeBean == null) {
				model.addAttribute("msg","ID does not exist");
				return "error";
			} else {
				model.addAttribute("traineeBean", traineeBean);
				return "deleteTrainee";
			}
		} catch (TraineeException e) {
			return "error";
		}

	}

	@RequestMapping(value = "/deleteTraineeRetreive", method = RequestMethod.POST)
	public String deleteByRetrieve(@RequestParam("traineeId") int traineeId,
			Model model) {
		try {
			
			TraineeBean traineeBean = traineeService
					.removeTraineeById(traineeId);
			
			model.addAttribute("message",
					"trainee with id : " + traineeBean.getTraineeId()
							+ " deleted Successfully");
			return "deleteSuccess";
		} catch (TraineeException e) {
			return "error";
		}

	}

	/*************************************
	 * Retrieve all
	 * *******************************/
	@RequestMapping("/ShowRetrieveAllTraineeForm")
	public String retrieveAll(Model model) {

		List<TraineeBean> list = new ArrayList<TraineeBean>();

		try {
			list = traineeService.getallDetail();
			if (list == null) {
				model.addAttribute("msg", "No Entites found");
				return "error";
			} else {
				model.addAttribute("traineeBean", list);
				return "retrieveAll";
			}

		} catch (TraineeException e) {
			return "error";
		}

	}

	/********************************
	 * Retrieve by id
	 * ***********************************/
	@RequestMapping("/ShowRetrieveTraineeForm")
	public String ShowRetrieveTrainee(Model model) {
		model.addAttribute("traineeBean", new TraineeBean());
		return "retrieve";

	}

	@RequestMapping(value="/retriveTraineeById", method = RequestMethod.POST)
	public String retriveTraineeById(
			@ModelAttribute("traineeBean") TraineeBean traineeBean, Model model) {

		try {
			traineeBean=traineeService.retrieveByID(traineeBean
					.getTraineeId());
			if (traineeBean==null) {
				model.addAttribute("msg","ID does not exist");
				return "error";
			} else {
				model.addAttribute("traineeBean", traineeBean);
				return "retrieve";
			}

		} catch (TraineeException e) {
			return "error";

		}

	}

	/*****************************
	 * To Modify Details
	 * *******************************/
	@RequestMapping("/ShowModifyTraineeForm")
	public String ShowModifyTrainee(Model model) {
		model.addAttribute("traineeBean", new TraineeBean());
		return "modify";
	}

	// modifyById

	@RequestMapping(value = "/modifyById", method = RequestMethod.POST)
	public String modifyById(
			@ModelAttribute("traineeBean") TraineeBean traineeBean, Model model) {
		try {
			traineeBean = traineeService.getTraineeById(traineeBean
					.getTraineeId());
			if (traineeBean == null) {
				model.addAttribute("msg", "ID does not exist");
				return "error";
			} else {
				model.addAttribute("traineeBean", traineeBean);

				ArrayList<String> locationList = new ArrayList<String>();
				locationList.add("Chennai");
				locationList.add("Bangalore");
				locationList.add("Pune");
				locationList.add("Mumbai");
				model.addAttribute("locationList", locationList);

				ArrayList<String> domainList = new ArrayList<String>();
				domainList.add("JEE");
				domainList.add(".Net");
				domainList.add("Mainframe");
				domainList.add("SAP");
				model.addAttribute("domainList", domainList);
				
				return "modify";
			}
			
		} catch (TraineeException e) {
			return "error";
		}

	}

	@RequestMapping(value = "/modifyTrainee", method = RequestMethod.POST)
	public String modifyTrainee(
			@ModelAttribute("traineeBean") TraineeBean traineeBean, Model model) {

		try {
			traineeBean = traineeService.modifyTrainee(traineeBean);
			model.addAttribute("message",
					"trainee with id :  " + traineeBean.getTraineeId()
							+ "  modified successfully!");
			model.addAttribute(traineeBean.getTraineeId());
			model.addAttribute(traineeBean.getTraineeName());
			model.addAttribute(traineeBean.getTraineeLocation());
			model.addAttribute(traineeBean.getTraineeDomain());
			return "modifySuccess";
		} catch (TraineeException e) {
			return "error";
		}

	}

}
