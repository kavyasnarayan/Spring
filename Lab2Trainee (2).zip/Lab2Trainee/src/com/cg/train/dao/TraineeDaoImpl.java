package com.cg.train.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.train.beans.TraineeBean;
import com.cg.train.controller.TraineeController;
import com.cg.train.exception.TraineeException;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public TraineeBean addTrainee(TraineeBean traineeBean)
			throws TraineeException {
		entityManager.persist(traineeBean);
		entityManager.flush();
		return traineeBean;
	}

	@Override
	public TraineeBean getTraineeById(int traineeId) throws TraineeException {

		TraineeBean traineeBean = entityManager.find(TraineeBean.class,
				traineeId);
		entityManager.flush();
		return traineeBean;
	}

	@Override
	public List<TraineeBean> getallDetail() throws TraineeException {
		TypedQuery<TraineeBean> query = entityManager.createQuery(
				"SELECT tid FROM TraineeBean tid", TraineeBean.class);
		return query.getResultList();
	}

	@Override
	public TraineeBean removeTraineeById(int traineeId) throws TraineeException {
		TraineeBean traineeBean = entityManager.find(TraineeBean.class,
				traineeId);
		entityManager.remove(traineeBean);

		return traineeBean;
	}

	@Override
	public TraineeBean retrieveByID(int traineeId) throws TraineeException {
		TraineeBean traineeBean = entityManager.find(TraineeBean.class,
				traineeId);
		entityManager.flush();
		return traineeBean;
	}

	@Override
	public TraineeBean modifyTrainee(TraineeBean traineeBean)
			throws TraineeException {
		entityManager.merge(traineeBean);

		return traineeBean;
	}
}
