package com.cg.train.dao;

import java.util.List;

import com.cg.train.beans.TraineeBean;
import com.cg.train.exception.TraineeException;

public interface ITraineeDao {
	public TraineeBean addTrainee(TraineeBean traineeBean) throws TraineeException;
	public TraineeBean getTraineeById(int traineeId) throws TraineeException;
	public TraineeBean removeTraineeById(int traineeId) throws TraineeException;
	public List<TraineeBean> getallDetail() throws TraineeException;
	public TraineeBean retrieveByID(int traineeId) throws TraineeException;
	public TraineeBean modifyTrainee(TraineeBean traineeBean) throws TraineeException;
}
