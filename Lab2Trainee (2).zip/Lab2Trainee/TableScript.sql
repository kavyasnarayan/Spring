DROP TABLE trainee_master;

CREATE TABLE trainee_master(
	trainee_id NUMBER PRIMARY KEY,
	trainee_name VARCHAR2(30),
	trainee_domain VARCHAR2(30),
	trainee_location VARCHAR2(30)
			);